import React from 'react';
import Button from '@mui/material/Button';
import Sidebar from '../layout/Sidebar';
import Formtable from './formTable';
import {useNavigate} from 'react-router-dom';
import { Bar } from '../layout/m';

const Home = () => {
  const navigate = useNavigate();
  const handleEmployeeFormOpen = () => {
    navigate('/forms')
  };

  return (
    <div>
      {/* <Sidebar /> */}
      <Bar/>
      {/* <div style={{ padding: '20px' ,margin:"30px 30px "}}>
        <Button
          variant="contained"
          color="primary"
          onClick={handleEmployeeFormOpen}
          style={{ float: 'right',marginTop:"30px" }}
        >
          Open Employee Form
        </Button>
        <Formtable />
      </div> */}
    </div>
  );
};

export default Home;
